import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Request } from './request.entity';
import { User } from './user.entity';

@Entity('approval_logs')
export class ApprovalLog {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Request)
  @JoinColumn({ name: 'request_id' })
  request: Request;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'approver_id' })
  approver: User;

  @Column({ type: 'varchar', length: 20 })
  action: 'Approve' | 'Reject' | 'SendBack';

  @Column({ type: 'text', nullable: true })
  comments: string;

  @Column({ type: 'timestamp with time zone', default: () => 'CURRENT_TIMESTAMP' })
  timestamp: Date;
}
